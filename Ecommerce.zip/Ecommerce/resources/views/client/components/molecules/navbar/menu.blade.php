<ul class="nav-list">
  <li class="nav-item">
    <a href="/" class="nav-link">Home</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientProducts') }}" class="nav-link">Products</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientCategory') }}" class="nav-link">Category</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientAbout') }}" class="nav-link">About</a>
  </li>
  <li class="nav-item">
    <a href="{{ route('clientCheckOrder') }}" class="nav-link">Check Order</a>
  </li>
</ul>