<div class="container py-5">
    <div class="row g-3">
        <x-molecules.discount-block background="primary" discount="30% OFF" item="Luxury Watches" image="watch.png" />
        <x-molecules.discount-block background="info" discount="45% OFF" item="Belt Black Smooth" image="belt.png" />
    </div>
</div>