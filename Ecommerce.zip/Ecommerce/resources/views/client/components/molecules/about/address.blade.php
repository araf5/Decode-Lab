<div class="address py-md-5 py-2" id="address">
  <div class="container">
    <div class="row">
      <div class="col-lg-4 col-md-4 col-12">
        <h3 class="font-primary"><u>Address</u></h3>
      </div>
      <div class="col-lg-8 col-md-8 col-12">
        <div class="responsive-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d65334052.59731062!2d78.05561483728009!3d-1.8785136045360042!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2c4c07d7496404b7%3A0xe37b4de71badf485!2sIndonesia!5e0!3m2!1sen!2sid!4v1657271630457!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>
  </div>
</div>